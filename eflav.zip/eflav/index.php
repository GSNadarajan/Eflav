
<?=include "_template/_header.php";?>
<body class="text-center">

    <main class="form-signin w-100 m-auto">
            <img class="mb-4" src="assets/brand/bootstrap-logo.svg" alt="" width="72" height="57">
            <h1 class="h1 mb-3 fw-normal text-white"> EFLAV</h1>

            <button class="w-100 order-btn btn btn-lg btn-primary" onclick="redirect()" type="submit">Tap to order</button>
    </main>

    <?=include("_template/_scripts.php")?>
</body>

</html>