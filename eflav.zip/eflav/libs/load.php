<?php

include "config.php";
include "session.class.php";
include "filter.class.php";
include "db.class.php";

session::start();